#ifndef HASH_SET_REFINABLE_H
#define HASH_SET_REFINABLE_H

#include <algorithm>
#include <atomic>
#include <functional>
#include <memory>
#include <mutex>
#include <shared_mutex>
#include <thread>
#include <vector>

#include "src/hash_set_base.h"

template <typename T>
class HashSetRefinable : public HashSetBase<T> {
 public:
  explicit HashSetRefinable(size_t initial_capacity)
      : buckets_(initial_capacity), size_(0), resizing_(false) {
    auto mutexes = std::make_shared<MutexArray>();

    for (size_t i = 0; i < initial_capacity; ++i) {
      mutexes->push_back(std::make_unique<std::mutex>());
    }

    std::atomic_store(&locks_, mutexes);
  }

  bool Add(T elem) final {
    const size_t hash = std::hash<T>()(elem);
    bool should_resize = false;

    {
      auto guard = Acquire(hash);
      auto& bucket = buckets_[hash % buckets_.size()];

      if (std::find(bucket.begin(), bucket.end(), elem) != bucket.end()) {
        return false;
      }

      bucket.push_back(elem);
      size_++;

      should_resize = size_.load() > buckets_.size();
    }

    // Resize must happen after releasing the bucket lock,
    // otherwise the resizing thread could wait on its own lock
    if (should_resize) {
      Resize();
    }

    return true;
  }

  bool Remove(T elem) final {
    const size_t hash = std::hash<T>()(elem);
    auto guard = Acquire(hash);

    auto& bucket = buckets_[hash % buckets_.size()];
    auto e = std::find(bucket.begin(), bucket.end(), elem);

    if (e == bucket.end()) {
      return false;
    }

    bucket.erase(e);
    size_--;

    return true;
  }

  [[nodiscard]] bool Contains(T elem) final {
    const size_t hash = std::hash<T>()(elem);
    auto guard = Acquire(hash);

    const auto& bucket = buckets_[hash % buckets_.size()];

    return std::find(bucket.begin(), bucket.end(), elem) != bucket.end();
  }

  [[nodiscard]] size_t Size() const final { return size_.load(); }

 private:
  using MutexArray = std::vector<std::unique_ptr<std::mutex>>;
  using MutexArrayPtr = std::shared_ptr<MutexArray>;

  // Keeps the mutex array alive until its mutex has been unlocked
  // Members are destroyed in reverse order: lock first, then mutexes
  struct BucketGuard {
    MutexArrayPtr mutexes;
    std::unique_lock<std::mutex> lock;
  };

  std::vector<std::vector<T>> buckets_;

  // Atomically replaceable array of bucket mutexes
  // Shared ownership keeps old arrays alive during concurrent access
  MutexArrayPtr locks_;

  std::atomic<size_t> size_;

  // Only one thread can resize at a time
  // Thread identity is unnecessary because reentrancy is forbidden
  std::atomic<bool> resizing_;

  BucketGuard Acquire(size_t hash) {
    while (true) {
      // Wait if another thread is resizing the table
      while (resizing_.load()) {
        std::this_thread::yield();
      }

      auto mutexes = std::atomic_load(&locks_);
      const size_t index = hash % mutexes->size();

      std::unique_lock<std::mutex> lock(*(*mutexes)[index]);

      // A resize could have happened while acquiring the mutex
      // Only proceed if this is still the current lock array
      if (!resizing_.load() && std::atomic_load(&locks_) == mutexes) {
        return {std::move(mutexes), std::move(lock)};
      }

      // Otherwise RAII releases the lock and we retry
    }
  }

  // Once resizing_ is set, new operations cannot successfully
  // pass Acquire(). Wait for existing bucket operations to finish
  void Quiesce(const MutexArrayPtr& mutexes) {
    for (auto& mutex : *mutexes) {
      std::scoped_lock lock(*mutex);
    }
  }

  void Resize() {
    bool expected = false;

    // Only one thread can claim ownership of resizing
    if (!resizing_.compare_exchange_strong(expected, true)) {
      return;
    }

    try {
      auto old_mutexes = std::atomic_load(&locks_);

      // Ensure no existing operation is accessing the old table
      Quiesce(old_mutexes);

      // Another thread may have already resized the table
      if (size_.load() > buckets_.size()) {
        const size_t new_capacity = buckets_.size() * 2;

        std::vector<std::vector<T>> new_buckets(new_capacity);
        auto new_mutexes = std::make_shared<MutexArray>();

        for (size_t i = 0; i < new_capacity; ++i) {
          new_mutexes->push_back(std::make_unique<std::mutex>());
        }

        // Rehash directly rather than calling Add(), since
        // recursive public operations are not permitted
        for (const auto& bucket : buckets_) {
          for (const auto& elem : bucket) {
            const size_t index = std::hash<T>()(elem) % new_capacity;
            new_buckets[index].push_back(elem);
          }
        }

        // Publish the new table and locks before clearing
        // the resize flag, so operations use the new generation
        buckets_.swap(new_buckets);
        std::atomic_store(&locks_, new_mutexes);
      }
    } catch (...) {
      resizing_.store(false);
      throw;
    }

    resizing_.store(false);
  }
};

#endif  // HASH_SET_REFINABLE_H
