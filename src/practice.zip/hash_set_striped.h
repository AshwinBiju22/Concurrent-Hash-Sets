#ifndef HASH_SET_STRIPED_H
#define HASH_SET_STRIPED_H

#include <atomic>
#include <functional>
#include <mutex>
#include <vector>

#include "src/hash_set_base.h"

template <typename T>
class HashSetStriped : public HashSetBase<T> {
 public:
  explicit HashSetStriped(size_t initial_capacity)
      : buckets_(initial_capacity), locks_(buckets_.size()), size_(0) {
    for (auto& lock : locks_) {
      lock = std::make_unique<std::mutex>();
    }
  }

  bool Add(T elem) final {
    const size_t hash = std::hash<T>()(elem);
    const size_t stripe = hash % locks_.size();

    bool should_resize = false;

    {
      std::scoped_lock lock(*locks_[stripe]);

      const size_t index = hash % buckets_.size();
      auto& bucket = buckets_[index];

      if (std::find(bucket.begin(), bucket.end(), elem) != bucket.end()) {
        return false;
      }

      bucket.push_back(elem);
      size_++;

      should_resize = size_ > buckets_.size();
    }

    if (should_resize) {
      Resize();
    }

    return true;
  }

  bool Remove(T elem) final {
    const size_t hash = std::hash<T>()(elem);
    const size_t stripe = hash % locks_.size();

    std::scoped_lock lock(*locks_[stripe]);

    const size_t index = hash % buckets_.size();
    auto& bucket = buckets_[index];

    auto it = std::find(bucket.begin(), bucket.end(), elem);

    if (it == bucket.end()) {
      return false;
    }

    bucket.erase(it);
    size_--;

    return true;
  }

  [[nodiscard]] bool Contains(T elem) final {
    const size_t hash = std::hash<T>()(elem);
    const size_t stripe = hash % locks_.size();

    std::scoped_lock lock(*locks_[stripe]);

    const size_t index = hash % buckets_.size();
    const auto& bucket = buckets_[index];

    return std::find(bucket.begin(), bucket.end(), elem) != bucket.end();
  }

  [[nodiscard]] size_t Size() const final { return size_.load(); }

 private:
  std::vector<std::vector<T>> buckets_;
  std::vector<std::unique_ptr<std::mutex>> locks_;
  std::atomic<size_t> size_;

  void Resize() {
    std::vector<std::unique_lock<std::mutex>> guards;

    for (auto& mutex : locks_) {
      guards.emplace_back(*mutex);
    }

    if (size_ <= buckets_.size()) {
      return;
    }

    size_t new_capacity = buckets_.size() * 2;
    std::vector<std::vector<T>> new_buckets(new_capacity);

    for (const auto& bucket : buckets_) {
      for (const auto& elem : bucket) {
        const size_t index = std::hash<T>()(elem) % new_capacity;
        new_buckets[index].push_back(elem);
      }
    }

    buckets_.swap(new_buckets);
  }
};

#endif  // HASH_SET_STRIPED_H
