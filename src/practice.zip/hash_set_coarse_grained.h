#ifndef HASH_SET_COARSE_GRAINED_H
#define HASH_SET_COARSE_GRAINED_H

#include <algorithm>
#include <functional>
#include <mutex>
#include <vector>

#include "src/hash_set_base.h"

template <typename T>
class HashSetCoarseGrained : public HashSetBase<T> {
 public:
  explicit HashSetCoarseGrained(size_t initial_capacity)
      : buckets_(initial_capacity), size_(0) {}

  bool Add(T elem) final {
    std::scoped_lock lock(mutex_);

    size_t index = GetBucketIndex(elem);
    auto& bucket = buckets_[index];

    if (std::find(bucket.begin(), bucket.end(), elem) != bucket.end()) {
      return false;
    }

    bucket.push_back(elem);
    size_++;

    if (size_ > buckets_.size()) {
      Resize();
    }

    return true;
  }

  bool Remove(T elem) final {
    std::scoped_lock lock(mutex_);

    size_t index = GetBucketIndex(elem);
    auto& bucket = buckets_[index];

    auto e = std::find(bucket.begin(), bucket.end(), elem);

    if (e == bucket.end()) {
      return false;
    }

    bucket.erase(e);
    size_--;
    return true;
  }

  [[nodiscard]] bool Contains(T elem) final {
    std::scoped_lock lock(mutex_);

    size_t index = GetBucketIndex(elem);
    auto& bucket = buckets_[index];

    return std::find(bucket.begin(), bucket.end(), elem) != bucket.end();
  }

  [[nodiscard]] size_t Size() const final {
    std::scoped_lock lock(mutex_);
    return size_;
  }

 private:
  std::vector<std::vector<T>> buckets_;
  size_t size_;
  mutable std::mutex mutex_;

  size_t GetBucketIndex(const T& elem) const {
    return std::hash<T>()(elem) % buckets_.size();
  }

  void Resize() {
    size_t new_capacity = buckets_.size() * 2;
    std::vector<std::vector<T>> new_buckets(new_capacity);

    for (const auto& bucket : buckets_) {
      for (const auto& elem : bucket) {
        size_t index = std::hash<T>()(elem) % new_capacity;
        new_buckets[index].push_back(elem);
      }
    }

    buckets_.swap(new_buckets);
  }
};

#endif  // HASH_SET_COARSE_GRAINED_H
