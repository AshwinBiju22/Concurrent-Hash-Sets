#ifndef HASH_SET_SEQUENTIAL_H
#define HASH_SET_SEQUENTIAL_H

#include <algorithm>
#include <functional>
#include <vector>

#include "src/hash_set_base.h"

template <typename T>
class HashSetSequential : public HashSetBase<T> {
 public:
  explicit HashSetSequential(size_t initial_capacity)
      : buckets_(initial_capacity), size_(0) {}

  bool Add(T elem) final {
    size_t index = GetBucketIndex(elem);
    auto& bucket = buckets_[index];

    if (std::find(bucket.begin(), bucket.end(), elem) != bucket.end()) {
      return false;
    }

    bucket.push_back(elem);
    size_++;
    return true;
  }

  bool Remove(T elem) final {
    size_t index = GetBucketIndex(elem);
    auto& bucket = buckets_[index];

    auto e = std::find(bucket.begin(), bucket.end(), elem);

    if (e == bucket.end()) {
      return false;
    }

    bucket.erase(e);
    size_--;
    return true;
  }

  [[nodiscard]] bool Contains(T elem) final {
    size_t index = GetBucketIndex(elem);
    auto& bucket = buckets_[index];

    return std::find(bucket.begin(), bucket.end(), elem) != bucket.end();
  }

  [[nodiscard]] size_t Size() const final { return size_; }

 private:
  std::vector<std::vector<T>> buckets_;
  size_t size_;

  size_t GetBucketIndex(const T& elem) const {
    return std::hash<T>()(elem) % buckets_.size();
  }
};

#endif  // HASH_SET_SEQUENTIAL_H
